﻿namespace Lecture6.Models
{
    public class Product
    {
        public int ProductID { get; set; }
        public string Name { get; set; }
    }
}
